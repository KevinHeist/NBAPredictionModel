import numpy as np
import pandas as pd
import torch 
from PIL import Image
from torch import nn, save, load
from torch.optim import Adam
from torch.utils.data import DataLoader
from torchvision import datasets
from torchvision.transforms import ToTensor
from torch.utils.data import TensorDataset, DataLoader
import torch.nn.functional as F

df1Games = pd.read_csv('ScoresCopy.csv', index_col=False)
df2Stats = pd.read_csv('TeamStatsDFFinalRevising.csv', index_col=False)

outputData = df1Games[['Home_Points','Away_Points']].to_numpy()
inputsData = df2Stats.to_numpy()

inputs = torch.from_numpy(outputData)
targets = torch.from_numpy(inputsData)

train_ds = TensorDataset(inputs, targets)
batch_size = 5
train_dl = DataLoader(train_ds, batch_size, shuffle=True)
next(iter(train_dl))

# Image Classifier Neural Network
class ScorePred(nn.Module): 
    def __init__(self):
        super().__init__()
        self.model = nn.Sequential(
            nn.Linear(10, 20), 
            nn.ReLU(),
            nn.Linear(20, 10), 
            nn.ReLU(),
            nn.Linear(10, 5), 
            nn.Tanh(),
            nn.Linear(5, 2),
            nn.ReLU()
        )

    def forward(self, x): 
        return self.model(x)

# Instance of the neural network, loss, optimizer 
clf = ScorePred().to('cpu')
opt = Adam(clf.parameters(), lr=1e-3)
loss_fn = nn.MSELoss() 

# Training flow 
if __name__ == "__main__": 
    for epoch in range(10): # train for 10 epochs
        for batch in train_dl: 
            X,y = batch 
            X, y = X.to('cpu'), y.to('cpu') 
            yhat = clf(X) 
            loss = loss_fn(yhat, y) 

            # Apply backprop 
            opt.zero_grad()
            loss.backward() 
            opt.step() 

        print(f"Epoch:{epoch} loss is {loss.item()}")
    
    with open('model_state.pt', 'wb') as f: 
        save(clf.state_dict(), f) 

    with open('model_state.pt', 'rb') as f: 
        clf.load_state_dict(load(f))  

